/**
 * Classe de exemplo.
 * 
 * @author David Buzatto
 */
public class ClasseExemplo {
    
    public static void main( String[] args ) {
        System.out.println( "Exemplo de código fonte!" );
    }
    
}
